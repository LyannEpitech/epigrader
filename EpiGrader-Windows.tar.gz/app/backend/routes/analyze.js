"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const zod_1 = require("zod");
const fs_1 = require("fs");
const path_1 = require("path");
const analysis_js_1 = require("../services/analysis.js");
const rubricStorage_js_1 = require("../services/rubricStorage.js");
const github_js_1 = require("../services/github.js");
const router = (0, express_1.Router)();
const analysisService = new analysis_js_1.AnalysisService();
// Load GitHub token from .env file directly
function loadGitHubToken() {
    try {
        const envPath = (0, path_1.resolve)(process.cwd(), '.env');
        const envContent = (0, fs_1.readFileSync)(envPath, 'utf-8');
        const match = envContent.match(/^GITHUB_TOKEN=(.+)$/m);
        if (match) {
            console.log('[DEBUG] Loaded GITHUB_TOKEN from .env file');
            return match[1].trim();
        }
    }
    catch (e) {
        console.log('[DEBUG] Could not load GITHUB_TOKEN from .env:', e);
    }
    return process.env.GITHUB_TOKEN || '';
}
const githubService = new github_js_1.GitHubService(loadGitHubToken());
const startAnalysisSchema = zod_1.z.object({
    repoUrl: zod_1.z.string().min(1, 'Repository URL is required'),
    rubricId: zod_1.z.string().min(1, 'Rubric ID is required'),
    pat: zod_1.z.string().optional(),
});
// POST /api/analyze - Start analysis job
router.post('/', async (req, res) => {
    try {
        const result = startAnalysisSchema.safeParse(req.body);
        if (!result.success) {
            return res.status(400).json({
                error: 'Validation failed',
                details: result.error.errors,
            });
        }
        const { repoUrl, rubricId, pat } = result.data;
        // Get rubric from storage
        const rubric = await rubricStorage_js_1.rubricStorage.getRubric(rubricId);
        if (!rubric) {
            return res.status(404).json({
                error: 'Rubric not found',
            });
        }
        // Create analysis job with optional PAT
        const job = analysisService.createJob(repoUrl, rubricId, rubric.criteria, pat);
        res.status(202).json({
            success: true,
            jobId: job.id,
            status: job.status,
            message: 'Analysis job started',
        });
    }
    catch (error) {
        console.error('Start analysis error:', error);
        res.status(500).json({
            error: 'Failed to start analysis',
        });
    }
});
// GET /api/analyze/cache/entries - List cached repositories (MUST be before /:jobId routes)
router.get('/cache/entries', (req, res) => {
    try {
        const stats = analysisService.getCacheStats();
        res.json({
            success: true,
            entries: stats.entries || [],
            totalEntries: stats.size || 0,
        });
    }
    catch (error) {
        console.error('Get cache entries error:', error);
        res.status(500).json({
            error: 'Failed to get cache entries',
        });
    }
});
// DELETE /api/analyze/cache - Clear all cache
router.delete('/cache', (req, res) => {
    try {
        analysisService.clearCache();
        res.json({
            success: true,
            message: 'Cache cleared successfully',
        });
    }
    catch (error) {
        console.error('Clear cache error:', error);
        res.status(500).json({
            error: 'Failed to clear cache',
        });
    }
});
// DELETE /api/analyze/cache/entry - Clear specific repo from cache
router.delete('/cache/entry', (req, res) => {
    try {
        const { repoUrl } = req.query;
        if (!repoUrl || typeof repoUrl !== 'string') {
            return res.status(400).json({
                error: 'repoUrl query parameter is required',
            });
        }
        analysisService.clearCacheEntry(repoUrl);
        res.json({
            success: true,
            message: 'Cache entry cleared successfully',
        });
    }
    catch (error) {
        console.error('Clear cache entry error:', error);
        res.status(500).json({
            error: 'Failed to clear cache entry',
        });
    }
});
// GET /api/analyze/status/:jobId - Get job status
router.get('/status/:jobId', (req, res) => {
    try {
        const { jobId } = req.params;
        const job = analysisService.getJob(jobId);
        if (!job) {
            return res.status(404).json({
                error: 'Job not found',
            });
        }
        res.json({
            jobId: job.id,
            status: job.status,
            progress: job.progress,
            result: job.result,
            error: job.error,
            createdAt: job.createdAt,
            updatedAt: job.updatedAt,
        });
    }
    catch (error) {
        console.error('Get job status error:', error);
        res.status(500).json({
            error: 'Failed to get job status',
        });
    }
});
// GET /api/analyze/history - Get analysis history
router.get('/history', (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const jobs = analysisService.getAllJobs().slice(0, limit);
        res.json({
            jobs: jobs.map((job) => ({
                jobId: job.id,
                repoUrl: job.repoUrl,
                rubricId: job.rubricId,
                status: job.status,
                progress: job.progress,
                steps: job.steps,
                totalScore: job.result?.totalScore,
                maxScore: job.result?.maxScore,
                createdAt: job.createdAt,
                updatedAt: job.updatedAt,
            })),
            total: jobs.length,
        });
    }
    catch (error) {
        console.error('Get history error:', error);
        res.status(500).json({
            error: 'Failed to get analysis history',
        });
    }
});
// GET /api/analyze/cache/stats - Get cache statistics
router.get('/cache/stats', (req, res) => {
    try {
        const stats = analysisService.getCacheStats();
        res.json(stats);
    }
    catch (error) {
        console.error('Get cache stats error:', error);
        res.status(500).json({
            error: 'Failed to get cache stats',
        });
    }
});
// GET /api/analyze/debug/files - Debug: list files in repo
router.get('/debug/files', async (req, res) => {
    try {
        const repoUrl = req.query.repoUrl;
        if (!repoUrl) {
            return res.status(400).json({ error: 'repoUrl query param required' });
        }
        const match = repoUrl.match(/github\.com\/([^/]+)\/([^/]+)/);
        if (!match) {
            return res.status(400).json({ error: 'Invalid GitHub URL' });
        }
        const owner = match[1];
        const repo = match[2].replace(/\.git$/, '');
        const tree = await githubService.getRepoTree(owner, repo);
        // Filter for code files (same logic as analysis.ts)
        const codeExtensions = [
            '.c', '.h', '.cpp', '.cc', '.cxx', '.hpp',
            '.py', '.pyc', '.pyo',
            '.js', '.jsx', '.ts', '.tsx', '.mjs',
            '.java', '.class', '.jar',
            '.go', '.mod', '.sum',
            '.rs', '.toml',
            '.rb', '.erb',
            '.php', '.phtml',
            '.swift',
            '.kt', '.kts',
            '.scala', '.sc',
            '.r', '.R',
            '.m', '.mm',
            '.cs', '.csproj',
            '.fs', '.fsx',
            '.hs', '.lhs',
            '.lua',
            '.pl', '.pm',
            '.sh', '.bash', '.zsh', '.fish',
            '.ps1', '.psm1',
            '.bat', '.cmd',
            '.sql',
            '.html', '.htm', '.xhtml',
            '.css', '.scss', '.sass', '.less',
            '.xml', '.xsl', '.xslt',
            '.json', '.yaml', '.yml', '.toml',
            '.md', '.markdown', '.rst',
            '.dockerfile', 'dockerfile',
            '.gitignore', '.gitattributes',
            '.env', '.env.example',
            'Makefile', 'makefile', 'GNUmakefile',
            'CMakeLists.txt', 'Cargo.toml', 'package.json',
            'requirements.txt', 'Pipfile', 'setup.py', 'pyproject.toml',
            'Gemfile', 'Rakefile',
            'pom.xml', 'build.gradle',
            'go.mod', 'go.sum',
        ];
        const codeFiles = tree.filter(item => {
            if (item.type !== 'blob')
                return false;
            if (item.path.startsWith('.'))
                return false;
            if (item.path.includes('node_modules'))
                return false;
            if (item.path.includes('vendor'))
                return false;
            if (item.path.includes('__pycache__'))
                return false;
            if (item.path.includes('.git/'))
                return false;
            if (item.path.includes('dist/'))
                return false;
            if (item.path.includes('build/'))
                return false;
            if (item.path.includes('target/'))
                return false;
            if (item.path.includes('bin/'))
                return false;
            if (item.path.includes('obj/'))
                return false;
            const path = item.path.toLowerCase();
            const fileName = path.split('/').pop() || '';
            if (codeExtensions.includes(fileName))
                return true;
            return codeExtensions.some(ext => path.endsWith(ext));
        });
        res.json({
            owner,
            repo,
            totalFiles: tree.length,
            codeFilesFound: codeFiles.length,
            allFiles: tree.map(t => t.path),
            filteredFiles: codeFiles.map(t => t.path),
        });
    }
    catch (error) {
        console.error('Debug files error:', error);
        res.status(500).json({
            error: 'Failed to fetch files',
            details: error instanceof Error ? error.message : String(error),
        });
    }
});
exports.default = router;
//# sourceMappingURL=analyze.js.map